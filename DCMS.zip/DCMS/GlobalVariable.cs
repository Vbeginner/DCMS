﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DCMS
{
    public class GlobalVariable
    {
        public static string UserId = string.Empty;
    }
}